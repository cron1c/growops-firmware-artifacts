# GrowOps Hub -- Initial USB Flash Script (Windows PowerShell)
# Target: esp32p4. Usage: .\flash.ps1 [PORT]
# Requires: pip install esptool

param([string]$Port = "COM3")
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$Meta = Get-Content "$Dir\bundle_meta.json" | ConvertFrom-Json
$BundleTarget = $Meta.target

Write-Host "Detecting chip on $Port..."
$ChipOut = & esptool --port $Port chip-id 2>&1 | Out-String
$Detected = python3 -c @"
t = r'''$ChipOut'''.lower()
if 'esp32-p4' in t or 'esp32p4' in t: print('esp32p4')
elif 'esp32-s3' in t:                 print('esp32s3')
elif 'esp32-c6' in t:                 print('esp32c6')
elif 'esp32-c3' in t:                 print('esp32c3')
elif 'esp32' in t:                    print('esp32')
else:                                 print('unknown')
"@

if ($Detected -eq "unknown") { Write-Error "Could not identify chip."; exit 1 }
if ($Detected -ne $BundleTarget) {
  Write-Error "Bundle targets $BundleTarget but detected $Detected."; exit 1
}
Write-Host "Chip validated: $Detected"

Write-Host "Erasing NVS..."
& esptool --chip $BundleTarget --port $Port --baud 460800 `
  erase-region 0x9000 0x5000
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$FlashArgs = @(
  "--chip", $BundleTarget, "--port", $Port, "--baud", "460800", "write-flash",
  "0x2000", "$Dir\bootloader.bin",
  "0x8000", "$Dir\partition-table.bin"
)
if (Test-Path "$Dir\ota-data.bin") { $FlashArgs += "0xe000", "$Dir\ota-data.bin" }
$FlashArgs += "0x20000", "$Dir\firmware.bin"

Write-Host "Flashing GrowOps Hub firmware to $Port..."
& esptool @FlashArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Done. Power-cycle the device."
