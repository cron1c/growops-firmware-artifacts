GrowOps Hub -- Initial USB Flash Bundle
Version: 0.1.4
Chip:    esp32p4
=======================================

Prerequisites
-------------
Install Python 3.8+ and esptool:
    pip install esptool

Linux / macOS
-------------
1. Connect the Hub via USB.
2. Run:
     chmod +x flash.sh
     ./flash.sh /dev/ttyUSB0

Windows (PowerShell)
--------------------
1. Connect the Hub via USB.
2. Find the COM port in Device Manager.
3. Run:
     .\flash.ps1 COM3

Flash map
---------
0x002000  bootloader.bin
0x008000  partition-table.bin
0x00e000  ota-data.bin (if present)
0x020000  firmware.bin

NOTE: This bundle targets esp32p4 only.
The flash scripts abort if a different chip is detected.
