#!/usr/bin/env bash
# GrowOps Hub -- Initial USB Flash Script (Linux/macOS)
# Target: esp32p4. Usage: ./flash.sh [PORT]
# Requires: pip install esptool

PORT="${1:-/dev/ttyUSB0}"
DIR="$(cd "$(dirname "$0")" && pwd)"

BUNDLE_TARGET=$(python3 -c "
import json, sys
try:
    d = json.load(open('${DIR}/bundle_meta.json'))
    print(d['target'])
except Exception as e:
    print('ERROR: ' + str(e), file=sys.stderr); sys.exit(1)
") || exit 1

echo "Detecting chip on ${PORT}..."
CHIP_OUTPUT=$(esptool --port "${PORT}" chip-id 2>&1)
DETECTED=$(echo "${CHIP_OUTPUT}" | python3 -c "
import sys
t = sys.stdin.read().lower()
if 'esp32-p4' in t or 'esp32p4' in t: print('esp32p4')
elif 'esp32-s3' in t:                 print('esp32s3')
elif 'esp32-c6' in t:                 print('esp32c6')
elif 'esp32-c3' in t:                 print('esp32c3')
elif 'esp32' in t:                    print('esp32')
else:                                 print('unknown')
")

if [ "${DETECTED}" = "unknown" ]; then
  echo "ERROR: Could not identify chip." >&2
  echo "${CHIP_OUTPUT}" | head -5 >&2
  exit 1
fi
if [ "${DETECTED}" != "${BUNDLE_TARGET}" ]; then
  echo "ERROR: Bundle targets ${BUNDLE_TARGET} but detected ${DETECTED}." >&2
  exit 1
fi
echo "Chip validated: ${DETECTED}"

set -e
echo "Erasing NVS (${PORT})..."
esptool --chip "${BUNDLE_TARGET}" --port "${PORT}" --baud 460800 \
  erase-region 0x9000 0x5000

FLASH_ARGS=(0x2000 "${DIR}/bootloader.bin"
  0x8000 "${DIR}/partition-table.bin")
[ -f "${DIR}/ota-data.bin" ] && FLASH_ARGS+=(0xe000 "${DIR}/ota-data.bin")
FLASH_ARGS+=(0x20000 "${DIR}/firmware.bin")

echo "Flashing GrowOps Hub firmware to ${PORT}..."
esptool --chip "${BUNDLE_TARGET}" --port "${PORT}" --baud 460800 \
  write-flash "${FLASH_ARGS[@]}"
echo "Done. Power-cycle the device."
